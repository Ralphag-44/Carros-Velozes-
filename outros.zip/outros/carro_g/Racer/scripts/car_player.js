class Car_Player extends Car{
    constructor(points, img){
    super(points, img)
    this.pre_p = []
    this.coli_point = []

    let num_jog = Cars.filter(item => item instanceof Car_Player).length
    this.keys = move_sets[num_jog]
    }


    update(){
        

        if(keys[this.keys[0]]){  super.control_mov(0) }

        if(keys[this.keys[1]]){ super.control_mov(1) }

        if(keys[this.keys[2]] && Math.abs(this.act_mov) > .5){ super.control_mov(2)  }

        if(keys[this.keys[3]] && Math.abs(this.act_mov) >  .5) { super.control_mov(3) }
 



        this.aplc_mov()

    }


}