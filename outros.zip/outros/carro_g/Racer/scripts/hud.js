class Hud{
    constructor(){
        
        this.veloci_grade = new Image()
        this.veloci_grade.src = "imgs/veloci_grade.png"

        this.velo_indic = new Image()
        this.velo_indic.src = "imgs/velo_indic.png"

        this.current_ang = [0 , 0, 0]
    }

    update(){

        const gradeWidth = 0.18229 * canvas.width;   // 350/1920
        const gradeHeight = 0.32407 * canvas.height; // 350/1080
        const margin = -0.03 * canvas.width;       // 50px (50/1920)
        const bottomMargin = -0.06 * canvas.height; // 50px (50/1080)
        
        for (let i = 0; i < Cars.length; i++) {
            
            let baseX, baseY;
            
            // Define a posição base para cada velocímetro
            if (i === 0) {
                // Centralizado embaixo
                baseX = (canvas.width - gradeWidth) / 2;
                baseY = canvas.height - gradeHeight - bottomMargin;
            } else if (i === 1) {
                // Canto inferior esquerdo
                baseX = margin;
                baseY = canvas.height - gradeHeight - bottomMargin;
            } else if (i === 2) {
                // Canto inferior direito
                baseX = canvas.width - gradeWidth - margin;
                baseY = canvas.height - gradeHeight - bottomMargin;
            } else {
                // Caso tenha mais de 3 carros, posiciona em linha acima
                baseX = margin + (i % 3) * (gradeWidth + margin);
                baseY = canvas.height - gradeHeight - bottomMargin - (Math.floor(i / 3) * (gradeHeight + margin));
            }
        
            // Desenha o fundo do velocímetro
            ctx.drawImage(
                this.veloci_grade,
                baseX,
                baseY,
                gradeWidth,
                gradeHeight
            );
        
            ctx.save();
        
            // Calcula o ângulo do ponteiro
            let ang_d = Math.abs(parseFloat((Cars[i].act_mov).toFixed(2))) * 46;
            this.current_ang[i] += (ang_d - this.current_ang[i]) * 0.05;
            let ang_r = this.current_ang[i] * Math.PI / 180;
        
            // Centraliza a rotação
            ctx.translate(
                baseX + (gradeWidth / 2),
                baseY + (gradeHeight / 2)
            );
            
            ctx.rotate(ang_r);
            
            // Desenha o ponteiro
            ctx.drawImage(
                this.velo_indic,
                -gradeWidth / 2,
                -gradeHeight / 2,
                gradeWidth,
                gradeHeight
            );
        
            ctx.restore();
        }
    }
}