class Obs {
    constructor(){
        

        let obs_points_1 = [{x: 0.15625 * canvas.width, y: 0.05 * canvas.height}, {x: 0.38698 * canvas.width, y: 0.05 * canvas.height}];   
        let obs_points_2 = [{x: 0.27161 * canvas.width, y: 0.04815 * canvas.height}, {x: 0.40755 * canvas.width, y: 0.05463 * canvas.height}];
        let obs_points_3 = [{x: 0.40755 * canvas.width, y: 0.05463 * canvas.height}, {x: 0.45182 * canvas.width, y: 0.08981 * canvas.height}];
        let obs_points_4 = [{x: 0.45182 * canvas.width, y: 0.08981 * canvas.height}, {x: 0.47839 * canvas.width, y: 0.14352 * canvas.height}];
        let obs_points_5 = [{x: 0.47839 * canvas.width, y: 0.14352 * canvas.height}, {x: 0.47839 * canvas.width, y: 0.16852 * canvas.height}];
        let obs_points_6 = [{x: 0.47839 * canvas.width, y: 0.16852 * canvas.height}, {x: 0.4888 * canvas.width, y: 0.20093 * canvas.height}];
        let obs_points_7 = [{x: 0.4888 * canvas.width, y: 0.20093 * canvas.height}, {x: 0.51224 * canvas.width, y: 0.20278 * canvas.height}];
        let obs_points_8 = [{x: 0.51224 * canvas.width, y: 0.20278 * canvas.height}, {x: 0.52266 * canvas.width, y: 0.18796 * canvas.height}];
        let obs_points_9 = [{x: 0.52266 * canvas.width, y: 0.18796 * canvas.height}, {x: 0.52526 * canvas.width, y: 0.16759 * canvas.height}];
        let obs_points_10 = [{x: 0.52526 * canvas.width, y: 0.16759 * canvas.height}, {x: 0.52578 * canvas.width, y: 0.13611 * canvas.height}];
        let obs_points_11 = [{x: 0.52578 * canvas.width, y: 0.13611 * canvas.height}, {x: 0.56745 * canvas.width, y: 0.07315 * canvas.height}];
        let obs_points_12 = [{x: 0.56745 * canvas.width, y: 0.07315 * canvas.height}, {x: 0.58151 * canvas.width, y: 0.06852 * canvas.height}];
        let obs_points_13 = [{x: 0.58151 * canvas.width, y: 0.06852 * canvas.height}, {x: 0.6138 * canvas.width, y: 0.05185 * canvas.height}];
        let obs_points_14 = [{x: 0.6138 * canvas.width, y: 0.05185 * canvas.height}, {x: 0.83854 * canvas.width, y: 0.05185 * canvas.height}];
        let obs_points_15 = [{x: 0.83854 * canvas.width, y: 0.05185 * canvas.height}, {x: 0.86589 * canvas.width, y: 0.05741 * canvas.height}];
        let obs_points_16 = [{x: 0.86589 * canvas.width, y: 0.05741 * canvas.height}, {x: 0.88932 * canvas.width, y: 0.07315 * canvas.height}];
        let obs_points_17 = [{x: 0.88932 * canvas.width, y: 0.07315 * canvas.height}, {x: 0.92188 * canvas.width, y: 0.11111 * canvas.height}];
        let obs_points_18 = [{x: 0.92188 * canvas.width, y: 0.11111 * canvas.height}, {x: 0.93516 * canvas.width, y: 0.1463 * canvas.height}];
        let obs_points_19 = [{x: 0.93516 * canvas.width, y: 0.1463 * canvas.height}, {x: 0.93568 * canvas.width, y: 0.17037 * canvas.height}];
        let obs_points_20 = [{x: 0.93568 * canvas.width, y: 0.17037 * canvas.height}, {x: 0.93932 * canvas.width, y: 0.19444 * canvas.height}];
        let obs_points_21 = [{x: 0.93932 * canvas.width, y: 0.19444 * canvas.height}, {x: 0.93932 * canvas.width, y: 0.37407 * canvas.height}];
        let obs_points_22 = [{x: 0.93932 * canvas.width, y: 0.37407 * canvas.height}, {x: 0.92943 * canvas.width, y: 0.4287 * canvas.height}];
        let obs_points_23 = [{x: 0.92943 * canvas.width, y: 0.4287 * canvas.height}, {x: 0.91732 * canvas.width, y: 0.46111 * canvas.height}];
        let obs_points_24 = [{x: 0.91732 * canvas.width, y: 0.46111 * canvas.height}, {x: 0.8737 * canvas.width, y: 0.50278 * canvas.height}];
        let obs_points_25 = [{x: 0.8737 * canvas.width, y: 0.50278 * canvas.height}, {x: 0.85078 * canvas.width, y: 0.50741 * canvas.height}];
        let obs_points_26 = [{x: 0.85078 * canvas.width, y: 0.50741 * canvas.height}, {x: 0.69714 * canvas.width, y: 0.50648 * canvas.height}];
        let obs_points_27 = [{x: 0.69714 * canvas.width, y: 0.50648 * canvas.height}, {x: 0.68503 * canvas.width, y: 0.525 * canvas.height}];
        let obs_points_28 = [{x: 0.68503 * canvas.width, y: 0.525 * canvas.height}, {x: 0.68451 * canvas.width, y: 0.71852 * canvas.height}];
        let obs_points_29 = [{x: 0.68451 * canvas.width, y: 0.71852 * canvas.height}, {x: 0.69974 * canvas.width, y: 0.74074 * canvas.height}];
        let obs_points_30 = [{x: 0.69974 * canvas.width, y: 0.74074 * canvas.height}, {x: 0.80797 * canvas.width, y: 0.74259 * canvas.height}];
        let obs_points_31 = [{x: 0.80797 * canvas.width, y: 0.74259 * canvas.height}, {x: 0.8138 * canvas.width, y: 0.73241 * canvas.height}];
        let obs_points_32 = [{x: 0.8138 * canvas.width, y: 0.73241 * canvas.height}, {x: 0.8138 * canvas.width, y: 0.70648 * canvas.height}];
        let obs_points_33 = [{x: 0.8138 * canvas.width, y: 0.70648 * canvas.height}, {x: 0.79753 * canvas.width, y: 0.7 * canvas.height}];
        let obs_points_34 = [{x: 0.79753 * canvas.width, y: 0.7 * canvas.height}, {x: 0.70234 * canvas.width, y: 0.7 * canvas.height}];
        let obs_points_35 = [{x: 0.70234 * canvas.width, y: 0.7 * canvas.height}, {x: 0.69753 * canvas.width, y: 0.69074 * canvas.height}];
        let obs_points_36 = [{x: 0.69753 * canvas.width, y: 0.69074 * canvas.height}, {x: 0.69557 * canvas.width, y: 0.65833 * canvas.height}];
        let obs_points_37 = [{x: 0.69557 * canvas.width, y: 0.65833 * canvas.height}, {x: 0.69557 * canvas.width, y: 0.54722 * canvas.height}];
        let obs_points_38 = [{x: 0.69557 * canvas.width, y: 0.54722 * canvas.height}, {x: 0.84141 * canvas.width, y: 0.55 * canvas.height}];
        let obs_points_39 = [{x: 0.84141 * canvas.width, y: 0.55 * canvas.height}, {x: 0.86745 * canvas.width, y: 0.55833 * canvas.height}];
        let obs_points_40 = [{x: 0.86745 * canvas.width, y: 0.55833 * canvas.height}, {x: 0.8901 * canvas.width, y: 0.57407 * canvas.height}];
        let obs_points_41 = [{x: 0.8901 * canvas.width, y: 0.57407 * canvas.height}, {x: 0.92786 * canvas.width, y: 0.6213 * canvas.height}];
        let obs_points_42 = [{x: 0.92786 * canvas.width, y: 0.6213 * canvas.height}, {x: 0.93672 * canvas.width, y: 0.65926 * canvas.height}];
        let obs_points_43 = [{x: 0.93672 * canvas.width, y: 0.65926 * canvas.height}, {x: 0.93984 * canvas.width, y: 0.69352 * canvas.height}];
        let obs_points_44 = [{x: 0.93984 * canvas.width, y: 0.69352 * canvas.height}, {x: 0.93984 * canvas.width, y: 0.79537 * canvas.height}];
        let obs_points_45 = [{x: 0.93984 * canvas.width, y: 0.79537 * canvas.height}, {x: 0.91732 * canvas.width, y: 0.84259 * canvas.height}];
        let obs_points_46 = [{x: 0.91732 * canvas.width, y: 0.84259 * canvas.height}, {x: 0.8849 * canvas.width, y: 0.875 * canvas.height}];
        let obs_points_47 = [{x: 0.8849 * canvas.width, y: 0.875 * canvas.height}, {x: 0.84609 * canvas.width, y: 0.88796 * canvas.height}];
        let obs_points_48 = [{x: 0.84609 * canvas.width, y: 0.88796 * canvas.height}, {x: 0.81888 * canvas.width, y: 0.89074 * canvas.height}];
        let obs_points_49 = [{x: 0.81888 * canvas.width, y: 0.89074 * canvas.height}, {x: 0.66953 * canvas.width, y: 0.89074 * canvas.height}];
        let obs_points_50 = [{x: 0.66953 * canvas.width, y: 0.89074 * canvas.height}, {x: 0.64375 * canvas.width, y: 0.88611 * canvas.height}];
        let obs_points_51 = [{x: 0.64375 * canvas.width, y: 0.88611 * canvas.height}, {x: 0.61107 * canvas.width, y: 0.86389 * canvas.height}];
        let obs_points_52 = [{x: 0.61107 * canvas.width, y: 0.86389 * canvas.height}, {x: 0.58464 * canvas.width, y: 0.83241 * canvas.height}];
        let obs_points_53 = [{x: 0.58464 * canvas.width, y: 0.83241 * canvas.height}, {x: 0.57266 * canvas.width, y: 0.80556 * canvas.height}];
        let obs_points_54 = [{x: 0.57266 * canvas.width, y: 0.80556 * canvas.height}, {x: 0.57005 * canvas.width, y: 0.78426 * canvas.height}];
        let obs_points_55 = [{x: 0.57005 * canvas.width, y: 0.78426 * canvas.height}, {x: 0.57005 * canvas.width, y: 0.47315 * canvas.height}];
        let obs_points_56 = [{x: 0.57005 * canvas.width, y: 0.47315 * canvas.height}, {x: 0.57682 * canvas.width, y: 0.43981 * canvas.height}];
        let obs_points_57 = [{x: 0.57682 * canvas.width, y: 0.43981 * canvas.height}, {x: 0.59089 * canvas.width, y: 0.40556 * canvas.height}];
        let obs_points_58 = [{x: 0.59089 * canvas.width, y: 0.40556 * canvas.height}, {x: 0.61888 * canvas.width, y: 0.37685 * canvas.height}];
        let obs_points_59 = [{x: 0.61888 * canvas.width, y: 0.37685 * canvas.height}, {x: 0.64245 * canvas.width, y: 0.36204 * canvas.height}];
        let obs_points_60 = [{x: 0.64245 * canvas.width, y: 0.36204 * canvas.height}, {x: 0.80729 * canvas.width, y: 0.35648 * canvas.height}];
        let obs_points_61 = [{x: 0.80729 * canvas.width, y: 0.35648 * canvas.height}, {x: 0.82099 * canvas.width, y: 0.34259 * canvas.height}];
        let obs_points_62 = [{x: 0.82099 * canvas.width, y: 0.34259 * canvas.height}, {x: 0.82526 * canvas.width, y: 0.33148 * canvas.height}];
        let obs_points_63 = [{x: 0.82526 * canvas.width, y: 0.33148 * canvas.height}, {x: 0.82526 * canvas.width, y: 0.21111 * canvas.height}];
        let obs_points_64 = [{x: 0.82526 * canvas.width, y: 0.21111 * canvas.height}, {x: 0.80273 * canvas.width, y: 0.19907 * canvas.height}];
        let obs_points_65 = [{x: 0.80273 * canvas.width, y: 0.19907 * canvas.height}, {x: 0.65208 * canvas.width, y: 0.19907 * canvas.height}];
        let obs_points_66 = [{x: 0.65208 * canvas.width, y: 0.19907 * canvas.height}, {x: 0.63542 * canvas.width, y: 0.21481 * canvas.height}];
        let obs_points_67 = [{x: 0.63542 * canvas.width, y: 0.21481 * canvas.height}, {x: 0.62099 * canvas.width, y: 0.23611 * canvas.height}];
        let obs_points_68 = [{x: 0.62099 * canvas.width, y: 0.23611 * canvas.height}, {x: 0.58099 * canvas.width, y: 0.31111 * canvas.height}];
        let obs_points_69 = [{x: 0.58099 * canvas.width, y: 0.31111 * canvas.height}, {x: 0.5612 * canvas.width, y: 0.32963 * canvas.height}];
        let obs_points_70 = [{x: 0.5612 * canvas.width, y: 0.32963 * canvas.height}, {x: 0.53307 * canvas.width, y: 0.34907 * canvas.height}];
        let obs_points_71 = [{x: 0.53307 * canvas.width, y: 0.34907 * canvas.height}, {x: 0.51432 * canvas.width, y: 0.35278 * canvas.height}];
        let obs_points_72 = [{x: 0.51432 * canvas.width, y: 0.35278 * canvas.height}, {x: 0.49089 * canvas.width, y: 0.35185 * canvas.height}];
        let obs_points_73 = [{x: 0.49089 * canvas.width, y: 0.35185 * canvas.height}, {x: 0.46641 * canvas.width, y: 0.34537 * canvas.height}];
        let obs_points_74 = [{x: 0.46641 * canvas.width, y: 0.34537 * canvas.height}, {x: 0.43099 * canvas.width, y: 0.32315 * canvas.height}];
        let obs_points_75 = [{x: 0.43099 * canvas.width, y: 0.32315 * canvas.height}, {x: 0.41276 * canvas.width, y: 0.29352 * canvas.height}];
        let obs_points_76 = [{x: 0.41276 * canvas.width, y: 0.29352 * canvas.height}, {x: 0.37734 * canvas.width, y: 0.23056 * canvas.height}];
        let obs_points_77 = [{x: 0.37734 * canvas.width, y: 0.23056 * canvas.height}, {x: 0.36849 * canvas.width, y: 0.21481 * canvas.height}];
        let obs_points_78 = [{x: 0.36849 * canvas.width, y: 0.21481 * canvas.height}, {x: 0.35703 * canvas.width, y: 0.20556 * canvas.height}];
        let obs_points_79 = [{x: 0.35703 * canvas.width, y: 0.20556 * canvas.height}, {x: 0.34089 * canvas.width, y: 0.2 * canvas.height}];
        let obs_points_80 = [{x: 0.34089 * canvas.width, y: 0.2 * canvas.height}, {x: 0.20286 * canvas.width, y: 0.2 * canvas.height}];
        let obs_points_81 = [{x: 0.20286 * canvas.width, y: 0.2 * canvas.height}, {x: 0.18307 * canvas.width, y: 0.21481 * canvas.height}];
        let obs_points_82 = [{x: 0.18307 * canvas.width, y: 0.21481 * canvas.height}, {x: 0.18307 * canvas.width, y: 0.33333 * canvas.height}];
        let obs_points_83 = [{x: 0.18307 * canvas.width, y: 0.33333 * canvas.height}, {x: 0.19557 * canvas.width, y: 0.35463 * canvas.height}];
        let obs_points_84 = [{x: 0.19557 * canvas.width, y: 0.35741 * canvas.height}, {x: 0.3513 * canvas.width, y: 0.35833 * canvas.height}];
        let obs_points_85 = [{x: 0.3513 * canvas.width, y: 0.35741 * canvas.height}, {x: 0.39922 * canvas.width, y: 0.38148 * canvas.height}];
        let obs_points_86 = [{x: 0.39922 * canvas.width, y: 0.38148 * canvas.height}, {x: 0.42682 * canvas.width, y: 0.43519 * canvas.height}];
        let obs_points_87 = [{x: 0.42682 * canvas.width, y: 0.43519 * canvas.height}, {x: 0.43359 * canvas.width, y: 0.4963 * canvas.height}];
        let obs_points_88 = [{x: 0.43359 * canvas.width, y: 0.4963 * canvas.height}, {x: 0.43359 * canvas.width, y: 0.77685 * canvas.height}];
        let obs_points_89 = [{x: 0.43359 * canvas.width, y: 0.77685 * canvas.height}, {x: 0.42266 * canvas.width, y: 0.82315 * canvas.height}];
        let obs_points_90 = [{x: 0.42266 * canvas.width, y: 0.82315 * canvas.height}, {x: 0.38828 * canvas.width, y: 0.86944 * canvas.height}];
        let obs_points_91 = [{x: 0.38828 * canvas.width, y: 0.86944 * canvas.height}, {x: 0.3543 * canvas.width, y: 0.88704 * canvas.height}];
        let obs_points_92 = [{x: 0.3543 * canvas.width, y: 0.88704 * canvas.height}, {x: 0.32839 * canvas.width, y: 0.89167 * canvas.height}];
        let obs_points_93 = [{x: 0.32839 * canvas.width, y: 0.89167 * canvas.height}, {x: 0.16693 * canvas.width, y: 0.89167 * canvas.height}];
        let obs_points_94 = [{x: 0.16693 * canvas.width, y: 0.89167 * canvas.height}, {x: 0.13724 * canvas.width, y: 0.88426 * canvas.height}];
        let obs_points_95 = [{x: 0.13724 * canvas.width, y: 0.88426 * canvas.height}, {x: 0.10547 * canvas.width, y: 0.86481 * canvas.height}];
        let obs_points_96 = [{x: 0.10547 * canvas.width, y: 0.86481 * canvas.height}, {x: 0.07839 * canvas.width, y: 0.82963 * canvas.height}];
        let obs_points_97 = [{x: 0.07839 * canvas.width, y: 0.82963 * canvas.height}, {x: 0.06432 * canvas.width, y: 0.78704 * canvas.height}];
        let obs_points_98 = [{x: 0.06432 * canvas.width, y: 0.78704 * canvas.height}, {x: 0.06432 * canvas.width, y: 0.67037 * canvas.height}];
        let obs_points_99 = [{x: 0.06432 * canvas.width, y: 0.67037 * canvas.height}, {x: 0.08516 * canvas.width, y: 0.60278 * canvas.height}];
        let obs_points_100 = [{x: 0.08516 * canvas.width, y: 0.60278 * canvas.height}, {x: 0.10911 * canvas.width, y: 0.575 * canvas.height}];
        let obs_points_101 = [{x: 0.10911 * canvas.width, y: 0.575 * canvas.height}, {x: 0.12891 * canvas.width, y: 0.55926 * canvas.height}];
        let obs_points_102 = [{x: 0.12891 * canvas.width, y: 0.55926 * canvas.height}, {x: 0.15703 * canvas.width, y: 0.55093 * canvas.height}];
        let obs_points_103 = [{x: 0.15703 * canvas.width, y: 0.55093 * canvas.height}, {x: 0.31172 * canvas.width, y: 0.55093 * canvas.height}];
        let obs_points_104 = [{x: 0.31172 * canvas.width, y: 0.55093 * canvas.height}, {x: 0.31172 * canvas.width, y: 0.67778 * canvas.height}];
        let obs_points_105 = [{x: 0.31172 * canvas.width, y: 0.67778 * canvas.height}, {x: 0.30391 * canvas.width, y: 0.70093 * canvas.height}];
        let obs_points_106 = [{x: 0.30391 * canvas.width, y: 0.70093 * canvas.height}, {x: 0.20495 * canvas.width, y: 0.70093 * canvas.height}];
        let obs_points_107 = [{x: 0.20495 * canvas.width, y: 0.70093 * canvas.height}, {x: 0.19557 * canvas.width, y: 0.71019 * canvas.height}];
        let obs_points_108 = [{x: 0.19557 * canvas.width, y: 0.71019 * canvas.height}, {x: 0.19557 * canvas.width, y: 0.73611 * canvas.height}];
        let obs_points_109 = [{x: 0.19557 * canvas.width, y: 0.73611 * canvas.height}, {x: 0.2013 * canvas.width, y: 0.74259 * canvas.height}];
        let obs_points_110 = [{x: 0.2013 * canvas.width, y: 0.74259 * canvas.height}, {x: 0.30339 * canvas.width, y: 0.74259 * canvas.height}];
        let obs_points_111 = [{x: 0.30339 * canvas.width, y: 0.74259 * canvas.height}, {x: 0.31784 * canvas.width, y: 0.7213 * canvas.height}];
        let obs_points_112 = [{x: 0.31784 * canvas.width, y: 0.7213 * canvas.height}, {x: 0.32135 * canvas.width, y: 0.70463 * canvas.height}];
        let obs_points_113 = [{x: 0.32318 * canvas.width, y: 0.70463 * canvas.height}, {x: 0.32344 * canvas.width, y: 0.52222 * canvas.height}];
        let obs_points_114 = [{x: 0.32214 * canvas.width, y: 0.52222 * canvas.height}, {x: 0.30964 * canvas.width, y: 0.5037 * canvas.height}];
        let obs_points_115 = [{x: 0.30964 * canvas.width, y: 0.5037 * canvas.height}, {x: 0.29714 * canvas.width, y: 0.50648 * canvas.height}];
        let obs_points_116 = [{x: 0.29714 * canvas.width, y: 0.50648 * canvas.height}, {x: 0.14245 * canvas.width, y: 0.50648 * canvas.height}];
        let obs_points_117 = [{x: 0.14245 * canvas.width, y: 0.50648 * canvas.height}, {x: 0.11745 * canvas.width, y: 0.49444 * canvas.height}];
        let obs_points_118 = [{x: 0.11745 * canvas.width, y: 0.49444 * canvas.height}, {x: 0.10234 * canvas.width, y: 0.48056 * canvas.height}];
        let obs_points_119 = [{x: 0.10234 * canvas.width, y: 0.48056 * canvas.height}, {x: 0.08255 * canvas.width, y: 0.45648 * canvas.height}];
        let obs_points_120 = [{x: 0.08255 * canvas.width, y: 0.45648 * canvas.height}, {x: 0.07161 * canvas.width, y: 0.41111 * canvas.height}];
        let obs_points_121 = [{x: 0.07161 * canvas.width, y: 0.41111 * canvas.height}, {x: 0.06484 * canvas.width, y: 0.38056 * canvas.height}];
        let obs_points_122 = [{x: 0.06484 * canvas.width, y: 0.38056 * canvas.height}, {x: 0.06484 * canvas.width, y: 0.1787 * canvas.height}];
        let obs_points_123 = [{x: 0.06484 * canvas.width, y: 0.1787 * canvas.height}, {x: 0.07109 * canvas.width, y: 0.13981 * canvas.height}];
        let obs_points_124 = [{x: 0.07109 * canvas.width, y: 0.13981 * canvas.height}, {x: 0.09036 * canvas.width, y: 0.09722 * canvas.height}];
        let obs_points_125 = [{x: 0.09036 * canvas.width, y: 0.09722 * canvas.height}, {x: 0.11016 * canvas.width, y: 0.075 * canvas.height}];
        let obs_points_126 = [{x: 0.11016 * canvas.width, y: 0.075 * canvas.height}, {x: 0.13776 * canvas.width, y: 0.05741 * canvas.height}];
        let obs_points_127 = [{x: 0.13776 * canvas.width, y: 0.05741 * canvas.height}, {x: 0.16016 * canvas.width, y: 0.05 * canvas.height}];
        let obs_points_128 = [{x: 0.28542 * canvas.width, y: 0.55 * canvas.height}, {x: 0.72083 * canvas.width, y: 0.55 * canvas.height}];
        let obs_points_129 = [{x: 0.28542 * canvas.width, y: 0.7 * canvas.height}, {x: 0.72083 * canvas.width, y: 0.7 * canvas.height}];
        let obs_points_130 = [{x: 0.21771 * canvas.width, y: 0.74074 * canvas.height}, {x: 0.21771 * canvas.width, y: 0.89537 * canvas.height}];
        let obs_points_131 = [{x: 0.30208 * canvas.width, y: 0.74074 * canvas.height}, {x: 0.30208 * canvas.width, y: 0.89537 * canvas.height}];
        let obs_points_132 = [{x: 0.71094 * canvas.width, y: 0.74074 * canvas.height}, {x: 0.71094 * canvas.width, y: 0.89537 * canvas.height}];
        let obs_points_133 = [{x: 0.79531 * canvas.width, y: 0.74074 * canvas.height}, {x: 0.79531 * canvas.width, y: 0.89537 * canvas.height}];

       

        this.walls_up= [
            new Base(obs_points_28),
            new Base(obs_points_35),
            new Base(obs_points_36),
            new Base(obs_points_37),
            new Base(obs_points_55),
            new Base(obs_points_87),
            new Base(obs_points_88),
            new Base(obs_points_104),
            new Base(obs_points_105),
            new Base(obs_points_111),
            new Base(obs_points_112),
            new Base(obs_points_113),
            new Base(obs_points_114),
            new Base(obs_points_115),


            
            
        ]

        this.walls_down = [
            new Base(obs_points_128),
            new Base(obs_points_129)
        ]


        this.walls_layer = [
            
            new Special_Obs(obs_points_130, "2"),
            new Special_Obs(obs_points_131, "1"),
            new Special_Obs(obs_points_132, "1"),
            new Special_Obs(obs_points_133, "2")

        ]

        
        // Criando as paredes
        this.walls = [



            new Base(obs_points_1),
            new Base(obs_points_2),
            new Base(obs_points_3),
            new Base(obs_points_4),
            new Base(obs_points_5),
            new Base(obs_points_6),
            new Base(obs_points_7),
            new Base(obs_points_8),
            new Base(obs_points_9),
            new Base(obs_points_10),
            new Base(obs_points_11),
            new Base(obs_points_12),
            new Base(obs_points_13),
            new Base(obs_points_14),
            new Base(obs_points_15),
            new Base(obs_points_16),
            new Base(obs_points_17),
            new Base(obs_points_18),
            new Base(obs_points_19),
            new Base(obs_points_20),
            new Base(obs_points_21),
            new Base(obs_points_22),
            new Base(obs_points_23),
            new Base(obs_points_24),
            new Base(obs_points_25),
            new Base(obs_points_26),
            new Base(obs_points_27),
            new Base(obs_points_29),
            new Base(obs_points_30),
            new Base(obs_points_31),
            new Base(obs_points_32),
            new Base(obs_points_33),
            new Base(obs_points_34),
            new Base(obs_points_38),
            new Base(obs_points_39),
            new Base(obs_points_40),
            new Base(obs_points_41),
            new Base(obs_points_42),
            new Base(obs_points_43),
            new Base(obs_points_44),
            new Base(obs_points_45),
            new Base(obs_points_46),
            new Base(obs_points_47),
            new Base(obs_points_48),
            new Base(obs_points_49),
            new Base(obs_points_50),
            new Base(obs_points_51),
            new Base(obs_points_52),
            new Base(obs_points_53),
            new Base(obs_points_54),
            new Base(obs_points_56),
            new Base(obs_points_57),
            new Base(obs_points_58),
            new Base(obs_points_59),
            new Base(obs_points_60),
            new Base(obs_points_61),
            new Base(obs_points_62),
            new Base(obs_points_63),
            new Base(obs_points_64),
            new Base(obs_points_65),
            new Base(obs_points_66),
            new Base(obs_points_67),
            new Base(obs_points_68),
            new Base(obs_points_69),
            new Base(obs_points_70),
            new Base(obs_points_71),
            new Base(obs_points_72),
            new Base(obs_points_73),
            new Base(obs_points_74),
            new Base(obs_points_75),
            new Base(obs_points_76),
            new Base(obs_points_77),
            new Base(obs_points_78),
            new Base(obs_points_79),
            new Base(obs_points_80),
            new Base(obs_points_81),
            new Base(obs_points_82),
            new Base(obs_points_83),
            new Base(obs_points_84),
            new Base(obs_points_85),
            new Base(obs_points_86),

            new Base(obs_points_89),
            new Base(obs_points_90),
            new Base(obs_points_91),
            new Base(obs_points_92),
            new Base(obs_points_93),
            new Base(obs_points_94),
            new Base(obs_points_95),
            new Base(obs_points_96),
            new Base(obs_points_97),
            new Base(obs_points_98),
            new Base(obs_points_99),
            new Base(obs_points_100),
            new Base(obs_points_101),
            new Base(obs_points_102),
            new Base(obs_points_103),
            new Base(obs_points_106),
            new Base(obs_points_107),
            new Base(obs_points_108),
            new Base(obs_points_109),
            new Base(obs_points_110),
            new Base(obs_points_116),
            new Base(obs_points_117),
            new Base(obs_points_118),
            new Base(obs_points_119),
            new Base(obs_points_120),
            new Base(obs_points_121),
            new Base(obs_points_122),
            new Base(obs_points_123),
            new Base(obs_points_124),
            new Base(obs_points_125),
            new Base(obs_points_126),
            new Base(obs_points_127)
       
                ];

    }

    draw(){

        for(i = 0; i < this.walls.length; i++){

        }
        
    }


}


