class Car_Com extends Car{
    constructor(points, img){
        super(points, img)
        this.ia = true
      
        this.timer = [
            0,  // Frente
            0,  // Ré/Freio
            0,  // Esquerda
            0   // Direita
        ]

        this.detecs = []

        this.stuck = [false, 0]

        this.last_rot = 0
    
    }

    update(){

        this.anal_way()


        if(this.timer[1]){ super.control_mov(1) }

         else if(this.timer[0] && this.act_mov < 3.8){  super.control_mov(0) }


        if(this.timer[2] && Math.abs(this.act_mov) > .5){ super.control_mov(2)  }

        else if(this.timer[3] && Math.abs(this.act_mov) > 0.5) { super.control_mov(3) }

        this.aplc_mov()

        for(let i = 0; i < this.timer.length; i ++)
            {
                this.timer[i] --
                this.timer[i] = (this.timer[i] + (this.timer[i]**2)**.5)/2
            }


    }

    set_data(){

        for(let i = 0, mod = -0.7; i < 5; i++, mod+=0.35){
            let dir = this.dest + mod

            this.detecs[i] = {}
            this.detecs[i].size = 20*this.act_mov + 100
            this.detecs[i] = {x:this.points[4].x + Math.cos(dir) * this.detecs[i].size, y:this.points[4].y + Math.sin(dir) *  this.detecs[i].size, color:"white", value:0, size:250}
        }




            for(let i = 0; i < this.detecs.length; i ++){  
           
                for(let i2 = 0; i2 <  this.poss_coli.length; i2++){

                    let tester = {}
                    tester.points = []
                    tester.points[0] =  {x:this.points[4].x, y:this.points[4].y}
                    tester.points[1] = {x:this.detecs[i].x, y:this.detecs[i].y}
                    tester.points[2] = {}

                     
                   
                  while(super.colide(tester, this.poss_coli[i2])[0]){
                    
                    tester.points[1].x = tester.points[0].x + .99 * (tester.points[1].x - tester.points[0].x)
                    tester.points[1].y = tester.points[0].y + .99 * (tester.points[1].y - tester.points[0].y)
                    
                    
                   }




                let originalDistance = ((this.detecs[i].x - this.points[4].x)**2 + (this.detecs[i].y - this.points[4].y)**2)**0.5

                let adjustedDistance = ((tester.points[1].x - this.points[4].x)**2 + (tester.points[1].y - this.points[4].y)**2)**0.5

                let dif = adjustedDistance / originalDistance;
                
                if (dif <  .2) {
                    this.detecs[i].color = "purple";
                    this.detecs[i].value = 5;
                } 
                else if (dif < .55) {
                    this.detecs[i].color = "red";
                    this.detecs[i].value = 2;
                } 
                else if (dif <  .75) {
                    this.detecs[i].color = "orange";
                    this.detecs[i].value = 1;
                } 
                else if (dif <  .999) {
                    this.detecs[i].color = "yellow";
                    this.detecs[i].value =  .5;
                }
                
                  
                
                   ctx.strokeStyle = this.detecs[i].color
                   ctx.strokeWidth = 1
                   ctx.beginPath()
                   ctx.moveTo(this.points[4].x, this.points[4].y)
                   ctx.lineTo(this.detecs[i].x, this.detecs[i].y)
                   ctx.stroke()
            
               
           }
   


        }

    }


    anal_way(){

   
        this.set_data()

        this.stuck[1]++


        if(this.detecs[2].value < 2 && !this.stuck[0]){
            this.timer[0]++
        }

        
        else{
            this.timer[1]+= 5
            this.timer[this.last_rot]+= 5

            this.timer[1] = Math.min(60, this.timer[1])
            this.timer[this.last_rot]= Math.min(60, this.timer[this.last_rot])
        }

        

       let free_way = (this.detecs[0].value)/4 + this.detecs[1].value - this.detecs[3].value + (this.detecs[4].value/4)

        
         
       

       if(free_way > 0){
        this.timer[3] += free_way/7  
        this.last_rot = 2

       }

       else if(free_way < 0){

        this.timer[2] += free_way/7  
        this.last_rot = 3
       }
       

       if(this.stuck[1] == 2){
        this.stuck.push(JSON.stringify(this.points[4]))
    
       }


       if(this.stuck[1] == 32 ){
        this.stuck.push(JSON.stringify(this.points[4]))

        
            if(this.stuck[2] === this.stuck[3]){

                console.log(this.stuck)
 
                this.timer[1]+= 5
                this.timer[this.last_rot]+= 5


                this.stuck = [false, 1]
                
            }
       }

    
    }
}   