class cars  {
    constructor(){
        this.real_time = true
        this.ind = - 1
        this.replay_state = false
        this.backup = []
        this.replay_ind = -1

 
     } 

    up_draw(){
        
    for(let i = 0; i < Cars.length; i++){
        if(Cars[i].layer == "up"){

            Cars[i].draw_i()      
            Cars[i].draw()
         }
         
        }

    }

    down_draw(){

        
    for(let i = 0; i < Cars.length; i++){
        if(Cars[i].layer == "down"){

            Cars[i].draw_i()
            Cars[i].draw()
         }
    }
    }

    
    update(){   

       if(this.real_time && !this.replay_state){
            this.ind++

            for(let i = 0; i < Cars.length; i ++){

            this.Cars_Memory[i][0].push(JSON.stringify(Cars[i].points))
            this.Cars_Memory[i][1].push(JSON.stringify(Cars[i].mark))
            this.Cars_Memory[i][2].push(JSON.stringify(Cars[i].ang))
        }
       
    }

 
    if(keys[82] && !this.replay_state) {
  
          this.replay_state = true

            this.replay_ind = this.ind - Math.min(200, this.ind)

 
            for(let i = 0; i < Cars.length; i ++){

            this.backup[i][0] = (JSON.stringify(Cars[i].points))
            this.backup[i][1] = (JSON.stringify(Cars[i].mark))
            this.backup[i][2] = (JSON.stringify(Cars[i].ang))
        }

        console.log(this.backup)
    }
     
    if( this.replay_state){
        this.replay()}
    
         
    if(keys[8] && this.real_time && ! this.replay_state) {this.real_time = false}
    if(!this.real_time){
        this.reset()}



        for(let j = 0; j < Cars.length; j++){
            Cars[j].pre_p =  [JSON.stringify(Cars[j].points), Cars[j].ang]
        }

         for(let i = 0; i < Cars.length; i++){
            Cars[i].update()   
        }

        this.layer_switch()

        for(let j = 0; j < Cars.length; j++){

            let obj_coli = Pista.walls.concat(Cars.slice(j-1, j), Cars.slice(j+1, Cars.length))
         
            if(Cars[j].layer == "up"){ obj_coli = obj_coli.concat(Pista.walls_up)}
         
            else{ obj_coli = obj_coli.concat(Pista.walls_down)}

            Cars[j].poss_coli = obj_coli
           
            for(let i = 0; i < obj_coli.length; i ++){  
                
                let res = Cars[j].colide( Cars[j], obj_coli[i])
             
                if(res[0]){
                     Cars[j].act_mov *= .8
                     Cars[j].dest = Cars[j].dest +  ((Cars[j].dest_alv * (180/Math.PI) - Cars[j].dest * (180/Math.PI))*.2) * (Math.PI/180)
                     Cars[j].points = JSON.parse(Cars[j].pre_p[0])
                     Cars[j].ang = Cars[j].pre_p[1]

                     if(obj_coli[i] instanceof Car_Player)
                        {
                        let avarage = (obj_coli[i].act_mov + Cars[j].act_mov)/2
                   
                        Cars[j].act_mov = avarage
                        obj_coli[i].act_mov = avarage
 
 
                     }
 
                }
            }
        }


        
        
    }

    layer_switch(){
        for (let i = 0; i < Cars.length; i++){
 
            for(let i2 = 0; i2 < Pista.walls_layer.length; i2 ++){
            
                if(Cars[i].colide(Cars[i], Pista.walls_layer[i2])[0] && Cars[i].layer_stage.indexOf(Pista.walls_layer[i2].type) == -1){
                    Cars[i].layer_stage += Pista.walls_layer[i2].type
                    console.log("coli")
            }
            if(Cars[i].layer_stage == "12")
            {      // console.log("12")
                    Cars[i].layer = "down"
                    Cars[i].layer_stage = ""
            }
                
            
            else if(Cars[i].layer_stage == "21")
            {       
                   // console.log("21")
                    Cars[i].layer = "up"
                    Cars[i].layer_stage = ""
            }
            }
        }
    }


    num_p(n){

        Cars = []
        this.Cars_Memory = []
        
        if(n == 1){
            ret(0.20052 * canvas.width, 0.1156 * canvas.height, 0.02865 * canvas.width, 0.03704 * canvas.height, "carro_1", "neon");
         
            
            
        }
        else if(n==2){

            ret(0.21052 * canvas.width, 0.07156 * canvas.height, 0.02865 * canvas.width, 0.03704 * canvas.height, "carro_1", "neon");
            ret(0.21052 * canvas.width, 0.12856 * canvas.height, 0.02865 * canvas.width, 0.04167 * canvas.height, "carro_1", "durt");

        }
        else if(n==3){
            ret(0.20052 * canvas.width, 0.05556 * canvas.height, 0.02865 * canvas.width, 0.03704 * canvas.height, "carro_1", "neon");
            ret(0.20052 * canvas.width, 0.10556 * canvas.height, 0.02865 * canvas.width, 0.04167 * canvas.height, "carro_1", "scar");
            ret(0.20052 * canvas.width, 0.15556 * canvas.height, 0.02865 * canvas.width, 0.04167 * canvas.height, "carro_1", "durt");

        }

                for(let i = 0; i < Cars.length; i ++){
                this.Cars_Memory.push([[], [], []])
                this.backup.push([[], [], []])
                 }

    }
    

        replay(){

 
         for(let i = 0; i < Cars.length; i ++){
             if((this.ind - this.replay_ind) <=  40)
                {
                    this.replay_ind = -1
                    break;   
                    
                }
            Cars[i].points = JSON.parse(this.Cars_Memory[i][0][ this.replay_ind])
            Cars[i].mark = JSON.parse(this.Cars_Memory[i][1][ this.replay_ind])
            Cars[i].ang = JSON.parse(this.Cars_Memory[i][2][ this.replay_ind    ])

            

        }

         this.replay_ind++
             

         if(this.replay_ind == 0 ){

            console.log(0)

             this.replay_ind = -1
             this.replay_state = false
            
            for(let i = 0; i < Cars.length; i ++){
            Cars[i].points = JSON.parse(this.backup[i][0])
            Cars[i].mark = JSON.parse(this.backup[i][1])
            Cars[i].ang =  JSON.parse(this.backup[i][2])
            }
 
           
        }

    }



    reset(){
         for(let i = 0; i < Cars.length; i ++){
            Cars[i].points = JSON.parse(this.Cars_Memory[i][0][this.ind])
            Cars[i].mark = JSON.parse(this.Cars_Memory[i][1][this.ind])
            Cars[i].ang = JSON.parse(this.Cars_Memory[i][2][this.ind])
        }

          this.ind--
             if(this.ind == 0){
            this.real_time = true
            this.ind = -1
            all_cars.num_p(numero_jogadores)

 
           
        }

    }




}

function ret(x1, y1, wid, hei, type, img){

    let x2 = x1+wid
    let y2 = y1+hei

    let points = [
        {x:x1, y:y1},
        {x:x2, y:y1},
        {x:x2, y:y2},
        {x:x1, y:y2}
    ]

    if(type == "carro_1"){
        Cars.push(new Car_Player(points, img))
    }
    else if(type == "carro_2"){
        Cars.push(new Car_Com(points, img))
    }

}