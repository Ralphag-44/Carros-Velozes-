class Base {
    constructor(points, img){

        this.points = points
        this.ia = false
        this.points.push(central(this.points))
        this.img = new Image()
        this.img.src = `imgs/${img}.png`

    }

    draw(){
       // ctx.drawImage(this.img, this.points[0].x, this.points[0].y, this.points[2].x-this.points[0].x, this.points[2].y-this.points[0].y)
       
       
        if(debug){
            if(this.points.length > 3){
                ctx.strokeStyle = "red"
                ctx.lineWidth = 3
             }
            else{
                ctx.strokeStyle = "blue"
                ctx.lineWidth = 4
 
            }
            if(this.ia){
                ctx.strokeStyle = "green"
                ctx.lineWidth = 3
            }


            ctx.beginPath()
            ctx.moveTo(this.points[this.points.length-2].x, this.points[this.points.length-2].y)
            for (let i = 0; i<this.points.length-1; i++){
                ctx.lineTo(this.points[i].x, this.points[i].y)
            }
            ctx.stroke()

        }
        
    }


    draw_i(){

        ctx.save(); 
        ctx.translate(this.points[4].x, this.points[4].y); 
        ctx.rotate(this.ang * Math.PI / 180);
        ctx.drawImage(this.img, -0.02135 * canvas.width, -0.02407 * canvas.height, 0.04167 * canvas.width,0.04352 * canvas.height);
        ctx.restore(); 
    }

    colide(entity_1, entity_2){
        
            let fig_a = entity_1.points  
            let fig_b = entity_2.points 
            const reta_a = []
            const reta_b = []
        
        
            for(let i = 0, len = fig_a.length-1; i < len; i++){
                reta_a.push({ x1:fig_a[i].x, 
                              y1:fig_a[i].y, 
                              x2:fig_a[(i+1)%len].x, 
                              y2:fig_a[(i+1)%len].y 
                            })
                }
        
            for(let i = 0, len = fig_b.length-1; i < len; i++){
            reta_b.push({ x1:fig_b[i].x, 
                          y1:fig_b[i].y, 
                          x2:fig_b[(i+1)%len].x, 
                          y2:fig_b[(i+1)%len].y 
                        })
            }
            
        
            for(let i = 0; i < reta_a.length; i ++){
                for(let i2 = 0; i2 < reta_b.length; i2++){
                
                    let x1 = reta_a[i].x1 
                    let x2 = reta_a[i].x2
                    let x3 = reta_b[i2].x1 
                    let x4 = reta_b[i2].x2        
                    let y1 = reta_a[i].y1 
                    let y2 = reta_a[i].y2 
                    let y3 = reta_b[i2].y1 
                    let y4 = reta_b[i2].y2        
            
                    let uA =  ((x4-x3)*(y1-y3) - (y4-y3)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
                    let uB = ((x2-x1)*(y1-y3) - (y2-y1)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));    
        
                if(uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1){
                   
                    let intersectionX = x1 + (uA * (x2-x1));
                    let intersectionY = y1 + (uA * (y2-y1));  
                    return [true, intersectionX, intersectionY]
                    
                }
            }
        }
        return [false]
        
    }
}


function central(points){
    
    let c_x = 0
    let c_y = 0

    for(i = 0; i < points.length; i++){

        c_x += parseFloat((points[i].x/points.length).toFixed(3))
        c_y += parseFloat((points[i].y/points.length).toFixed(3))
    }

    return {x:c_x, y:c_y}

}


