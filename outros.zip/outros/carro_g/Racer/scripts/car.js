class Car extends Base{
    constructor(points, img){
        super(points, img)
        this.max_vel =  .3
        this.ace_vel = .02
        this.forc_rot = 0.6
        this.act_mov = 0
        this.ang = 0
        this.layer_stage = ""
        this.layer = "up"
        this.dest = 0
        this.dest_alv = 0
        this.derra = .065
        this.poss_coli = []
        this.mark = {}
        this.mark.lines = [[JSON.parse(JSON.stringify(this.points))]]
        this.mark.intens = [1]
        this.test_time = []
      }
     

    control_mov(control)
    {   
         if(control == 2)
          { 
            this.ang -= this.forc_rot*this.act_mov
            this.rotate(-1)
          }
  
          if(control == 3)
          {
             this.ang += this.forc_rot*this.act_mov
             this.rotate(1)
          }
  
          
          if(control == 0)
          {
          
          this.dest_alv = this.ang * (Math.PI / 180)
          this.act_mov += this.ace_vel-(this.act_mov/100)
         // this.act_mov = Math.min(this.max_vel, this.act_mov)      
          }
  
  
          if(control == 1)  
          {
          this.dest_alv = this.ang * (Math.PI / 180)
         
          if(this.act_mov > 0){this.act_mov -= this.ace_vel+(this.act_mov/100)/1.5}
          else{this.act_mov -= this.ace_vel+(this.act_mov/100)}
          
         // this.act_mov = Math.max(-this.max_vel, this.act_mov)
            
          }

     

  
    }
     
     
      aplc_mov(){
        
       // this.dest_alv %= 6.28319

      //  this.dest_alv_inv = this.dest_alv
            

        
        this.dest +=  ((this.dest_alv * (180/Math.PI) - this.dest * (180/Math.PI))*(this.derra-this.act_mov/120)) * (Math.PI/180)
       
        if(Math.abs(this.act_mov) < 1){this.dest = this.dest_alv}
 
     //   this.dest = this.dest_alv
        
        
        this.ace_vel = (0.05 + Math.abs(this.act_mov)*0.0107) - parseInt(((0.02 + Math.abs(this.act_mov)*0.0175)/this.max_vel))*this.max_vel
        // console.log(this.act_mov)
        

        for(let i = 0; i < this.points.length; i++){
            this.points[i].x += Math.cos(this.dest) * (this.act_mov)
            this.points[i].y += Math.sin(this.dest) * (this.act_mov)
        }
         
        if(this.act_mov != 0){
            this.act_mov *= .984 + parseFloat((this.act_mov/1000).toFixed(5))
           // console.log((this.act_mov*24).toFixed(1))
         }
        

         this.mark.lines = this.mark.lines.slice(0,length-1).concat([this.mark.lines[this.mark.lines.length-1].concat([JSON.parse(JSON.stringify(this.points))])])

         this.mark.lines.push([JSON.parse(JSON.stringify(this.points))])
 
         this.mark.intens.push((Math.abs(this.dest_alv-this.dest))/1.4)

         
 

        // console.log(this.mark.lines)
         this.floor_mark()
        }

       rotate(dif){

      //  console.log(this.mark.lines)

        let rad = this.forc_rot*dif*this.act_mov * (Math.PI/180)
        let cos = Math.cos(rad)
        let sin = Math.sin(rad)
        
        let cx = this.points[4].x
        let cy = this.points[4].y
    
        
        for (let i = 0; i < this.points.length; i++){
            let p_rot_x = this.points[i].x - cx
            let p_rot_y = this.points[i].y - cy
        
            let rot_x = p_rot_x * cos - p_rot_y * sin
            let rot_y = p_rot_x * sin + p_rot_y * cos;
            
        
            this.points[i].x = rot_x + cx
            this.points[i].y = rot_y + cy    
        }

   

    }

    floor_mark()
    {
        
      

       let actual_marks = this.mark.lines.slice(0,length-1).concat([this.mark.lines[this.mark.lines.length-1].concat([this.points])])

        
   
       ctx.lineWidth = 5
       
       for(let i = 0; i < actual_marks.length; i ++){
        for(let j = 0; j < 4; j++){
            if(j==0 || j==3){
                ctx.strokeStyle = `rgba(0,0,0,${this.mark.intens[i]})`
                ctx.beginPath()
                ctx.moveTo(actual_marks[i][0][j].x,actual_marks[i][0][j].y)
                ctx.lineTo(actual_marks[i][1][j].x, actual_marks[i][1][j].y)
                ctx.stroke()
            }
   
        }

       }

       for(let i = 0; i < this.mark.intens.length; i ++){
        this.mark.intens[i]-=0.01   

        if(this.mark.intens[i] <= 0){
            this.mark.lines.splice(i, 1)
            this.mark.intens.splice(i, 1)


        }
        }



    }

    
}