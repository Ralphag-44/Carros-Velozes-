class Special_Obs extends Base{
    constructor(points, type){
    super(points)
    this.type = type
    }
}