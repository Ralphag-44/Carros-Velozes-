class Sound{
    constructor(){
        this.tokyo = new Audio("audio/tokyodrift.mp3");
        this.tokyo.volume = 0.1;
    };
};